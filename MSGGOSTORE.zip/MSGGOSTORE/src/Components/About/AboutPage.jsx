import React from "react";
import "./AboutPage.css";

import about1 from "../../Assets/About/about-1.jpg";
import about2 from "../../Assets/About/about-2.jpg";

import Services from "../../Components/Home/Services/Services";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { Autoplay } from "swiper/modules";

import brand1 from "../../Assets/Brands/brand1.png";
import brand2 from "../../Assets/Brands/brand2.png";
import brand3 from "../../Assets/Brands/brand3.png";
import brand4 from "../../Assets/Brands/brand4.png";
import brand5 from "../../Assets/Brands/brand5.png";
import brand6 from "../../Assets/Brands/brand6.png";
import brand7 from "../../Assets/Brands/brand7.png";

const AboutPage = () => {
  return (
    <>
      <div className="aboutSection">
        <h2>About MSGGO</h2>
        <img src={about1} alt="" />
        <div className="aboutContent">
          <h3>Our Story</h3>
          <h4>
          At MSG GO, we are committed to simplifying communication and store management for businesses of all sizes. We provide cutting-edge tools that help businesses stay connected with customers, streamline operations, and enhance efficiency. Our goal is to deliver reliable solutions that empower businesses to thrive in an increasingly digital world.
          </h4>
          <p>
          From real-time messaging systems to inventory tracking and customer management, MSG GO offers a comprehensive suite of services designed to drive growth. We’re passionate about making business operations smoother, faster, and more effective, allowing our clients to focus on what truly matters — their customers. 
            Seas lights seasons. Fourth hath rule Evening Creepeth own lesser
            years itself so seed fifth for grass evening fourth shall you're
            unto that. Had. Female replenish for yielding so saw all one to
            yielding grass you'll air sea it, open waters subdue, hath. Brought
            second Made. Be. Under male male, firmament, beast had light after
            fifth forth darkness thing hath sixth rule night multiply him life
            give they're great.
          </p>
          <div className="content1">
          <div className="contentBox">
  <h5>Our Mission</h5>
  <p>
    At MSG GO, our mission is to empower businesses with innovative communication and store management solutions. We strive to help businesses stay connected, efficient, and organized, fostering growth and success in a digital world.
  </p>
</div>

<div className="contentBox">
  <h5>Our Vision</h5>
  <p>
    Our vision is to become the leading provider of seamless communication and store management solutions. We aim to transform the way businesses operate, making them more agile and customer-focused with advanced technology that drives success.
  </p>
</div>

          </div>
          <div className="content2">
            <div className="imgContent">
              <img src={about2} alt="" />
            </div>
            <div className="textContent">
  <h5>The Company</h5>
  <p>
    MSG GO is a dynamic company dedicated to providing businesses with innovative solutions for seamless communication and efficient store management. We offer cutting-edge technology that helps businesses stay connected, organized, and ahead in today’s fast-paced world. Our team is committed to delivering reliable tools that enable growth, drive success, and foster strong customer relationships. At MSG GO, we’re not just about technology — we’re about transforming the way businesses operate.
  </p>
</div>

          </div>
        </div>
      </div>
      <Services />
      <div className="companyPartners">
        <h5>Company Partners</h5>
        <Swiper
          slidesPerView={1}
          loop={true}
          breakpoints={{
            640: {
              slidesPerView: 2,
              spaceBetween: 5,
            },

            768: {
              slidesPerView: 4,
              spaceBetween: 40,
            },

            1024: {
              slidesPerView: 5,
              spaceBetween: 50,
            },
          }}
          spaceBetween={10}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
          }}
          modules={[Autoplay]}
        >
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand1} alt="" />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand2} alt="" />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand3} alt="" />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand4} alt="" />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand5} alt="" />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand6} alt="" />
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="aboutBrands">
              <img src={brand7} alt="" />
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </>
  );
};

export default AboutPage;
