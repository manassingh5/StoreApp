// import React, { useEffect, useState } from "react";
// import Skeleton from "react-loading-skeleton";
// import { useParams, useNavigate } from "react-router-dom";
// import { useDispatch } from "react-redux";
// import { addToCart } from "../../Features/Cart/cartSlice";

// import { GoChevronLeft, GoChevronRight } from "react-icons/go";
// import { FaStar } from "react-icons/fa";
// import { FiHeart } from "react-icons/fi";
// import { PiShareNetworkLight } from "react-icons/pi";
// import toast from "react-hot-toast";

// import "./Productt.css"; // Assuming you will style the page similarly

// const Productt = () => {
//   const { storeId } = useParams(); // Get storeId from URL params
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [quantities, setQuantities] = useState({});
//   const [currentImg, setCurrentImg] = useState(0); // For the image gallery
//   const [highlightedColor, setHighlightedColor] = useState("#C8393D");
//   const [selectSize, setSelectSize] = useState("S");

//   const dispatch = useDispatch();
//   const navigate = useNavigate();

//   const addProductToCart = (product) => {
//     const productWithStore = {
//       ...product,
//       quantity: quantities[product.id] || 1, // Use the adjusted quantity
//       storeId,
//     };
//     dispatch(addToCart(productWithStore)); // Add product with quantity and storeId
//     toast.success("Added to cart!", {
//       duration: 2000,
//       style: {
//         backgroundColor: "#07bc0c",
//         color: "white",
//       },
//     });
//     navigate("/cart"); // Redirect to cart page
//   };

//   const updateQuantity = (productId, change) => {
//     setQuantities((prevQuantities) => ({
//       ...prevQuantities,
//       [productId]: Math.max(1, (prevQuantities[productId] || 1) + change),
//     }));
//   };

//   useEffect(() => {
//     const fetchProductsByStore = async () => {
//       try {
//         setLoading(true);
//         const response = await fetch(
//           `https://messagingapi.azurewebsites.net/api/Product/GetProductsByStore?storeId=${storeId}`
//         );
//         const data = await response.json();
//         setProducts(data);

//         // Initialize quantities for products
//         const initialQuantities = {};
//         data.forEach((product) => {
//           initialQuantities[product.id] = 1;
//         });
//         setQuantities(initialQuantities);
//       } catch (error) {
//         console.error("Error fetching products:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchProductsByStore();
//   }, [storeId]);

//   const Loading = () => (
//     <div className="my-4 py-4">
//       <div className="d-flex flex-wrap justify-content-center">
//         {[...Array(4)].map((_, index) => (
//           <div className="mx-4" key={index}>
//             <Skeleton height={400} width={250} />
//           </div>
//         ))}
//       </div>
//     </div>
//   );

//   const ShowProducts = () => (
//     <div className="py-4 my-4">
//       <div className="productSection">
//         {products.map((product) => (
//           <div key={product.id} className="productShowCase d-flex flex-wrap justify-content-between">
//             {/* Product Gallery */}
//             <div className="productGallery">
//               <div className="productThumb">
//                 {product.images?.map((img, index) => (
//                   <img
//                     key={index}
//                     src={img || "/placeholder.png"}
//                     onClick={() => setCurrentImg(index)}
//                     alt={product.name}
//                     height={60}
//                   />
//                 ))}
//               </div>
//               <div className="productFullImg">
//                 <img src={product.images?.[currentImg] || "/placeholder.png"} alt={product.name} height={400} />
//                 <div className="buttonsGroup">
//                   <button onClick={() => setCurrentImg(currentImg === 0 ? product.images.length - 1 : currentImg - 1)} className="directionBtn">
//                     <GoChevronLeft size={18} />
//                   </button>
//                   <button onClick={() => setCurrentImg(currentImg === product.images.length - 1 ? 0 : currentImg + 1)} className="directionBtn">
//                     <GoChevronRight size={18} />
//                   </button>
//                 </div>
//               </div>
//             </div>

//             {/* Product Details */}
//             <div className="productDetails">
//               <div className="productName">
//                 <h1>{product.name}</h1>
//               </div>
//               <div className="productRating">
//                 <FaStar color="#FEC78A" size={10} />
//                 <FaStar color="#FEC78A" size={10} />
//                 <FaStar color="#FEC78A" size={10} />
//                 <FaStar color="#FEC78A" size={10} />
//                 <FaStar color="#FEC78A" size={10} />
//                 <p>{product.reviews} reviews</p>
//               </div>
//               <div className="productPrice">
//                 <h3>${product.price.toFixed(2)}</h3>
//               </div>
//               <div className="productDescription">
//                 <p>{product.description || "No description available."}</p>
//               </div>

//               {/* Size & Color Selection */}
//               <div className="productSizeColor">
//                 {/* Size */}
//                 <div className="productSize">
//                   <p>Sizes</p>
//                   <div className="sizeBtn">
//                     {["XS", "S", "M", "L", "XL"].map((size) => (
//                       <button
//                         key={size}
//                         style={{
//                           borderColor: selectSize === size ? "#000" : "#e0e0e0",
//                         }}
//                         onClick={() => setSelectSize(size)}
//                       >
//                         {size}
//                       </button>
//                     ))}
//                   </div>
//                 </div>

//                 {/* Color */}
//                 <div className="productColor">
//                   <p>Color</p>
//                   <div className="colorBtn">
//                     {["#222222", "#C8393D", "#E4E4E4"].map((color, index) => (
//                       <button
//                         key={index}
//                         style={{
//                           backgroundColor: color,
//                           border: highlightedColor === color ? "0px solid #000" : "0px solid white",
//                           padding: "8px",
//                           margin: "5px",
//                         }}
//                         onClick={() => setHighlightedColor(color)}
//                       />
//                     ))}
//                   </div>
//                 </div>
//               </div>

//               {/* Quantity Control */}
//               <div className="productQuantityControl">
//                 <button onClick={() => updateQuantity(product.id, -1)}>-</button>
//                 <span>{quantities[product.id] || 1}</span>
//                 <button onClick={() => updateQuantity(product.id, 1)}>+</button>
//               </div>

//               {/* Add to Cart */}
//               <div className="productCartBtn">
//                 <button onClick={() => addProductToCart(product)}>Add to Cart</button>
//               </div>

//               {/* Wishlist & Share */}
//               <div className="productWishShare">
//                 <button onClick={() => console.log("Add to Wishlist")}>
//                   <FiHeart color="red" size={17} />
//                   <p>Add to Wishlist</p>
//                 </button>
//                 <div className="productShare">
//                   <PiShareNetworkLight size={22} />
//                   <p>Share</p>
//                 </div>
//               </div>

//               {/* Product Tags */}
//               <div className="productTags">
//                 <p><span>SKU:</span> N/A</p>
//                 <p><span>CATEGORIES:</span> Casual, Jackets, Men</p>
//                 <p><span>TAGS:</span> biker, black, leather</p>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );

//   return (
//     <>
   
//       <div className="container">
//         {loading ? <Loading /> : <ShowProducts />}
//       </div>
   
//     </>
//   );
// };

// export default Productt;

import React, { useEffect, useState } from "react";
import Skeleton from "react-loading-skeleton";
import { useParams, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { addToCart } from "../../Features/Cart/cartSlice";

import { GoChevronLeft, GoChevronRight } from "react-icons/go";
import { FaStar } from "react-icons/fa";
import { FiHeart } from "react-icons/fi";
import { PiShareNetworkLight } from "react-icons/pi";
import toast from "react-hot-toast";

import "./Productt.css"; // Assuming you will style the page similarly

const Productt = () => {
  const { storeId } = useParams(); // Get storeId from URL params
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [quantities, setQuantities] = useState({});
  const [currentImg, setCurrentImg] = useState(0); // For the image gallery
  const [highlightedColor, setHighlightedColor] = useState("#C8393D");
  const [selectSize, setSelectSize] = useState("S");

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const addProductToCart = (product) => {
    const productWithDetails = {
      productID: product.id, // Ensure this matches the key you need in the cartSlice
      productName: product.name,
      productPrice: product.price,
      quantity: quantities[product.id] || 1,  // Use the quantity from state
      storeId,
      productColor: highlightedColor,
      productSize: selectSize
    };

    dispatch(addToCart(productWithDetails)); // Dispatch with correct product details

    toast.success("Added to cart!", {
      duration: 2000,
      style: {
        backgroundColor: "#07bc0c",
        color: "white",
      },
    });
    navigate("/cart"); // Navigate to the cart page
  };

  const updateQuantity = (productId, change) => {
    setQuantities((prevQuantities) => ({
      ...prevQuantities,
      [productId]: Math.max(1, (prevQuantities[productId] || 1) + change),
    }));
  };

  useEffect(() => {
    const fetchProductsByStore = async () => {
      try {
        setLoading(true);
        const response = await fetch(
          `https://messagingapi.azurewebsites.net/api/Product/GetProductsByStore?storeId=${storeId}`
        );
        const data = await response.json();
        setProducts(data);

        // Initialize quantities for products
        const initialQuantities = {};
        data.forEach((product) => {
          initialQuantities[product.id] = 1;
        });
        setQuantities(initialQuantities);
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProductsByStore();
  }, [storeId]);

  const Loading = () => (
    <div className="my-4 py-4">
      <div className="d-flex flex-wrap justify-content-center">
        {[...Array(4)].map((_, index) => (
          <div className="mx-4" key={index}>
            <Skeleton height={400} width={250} />
          </div>
        ))}
      </div>
    </div>
  );

  const ShowProducts = () => (
    <div className="py-4 my-4">
      <div className="productSection">
        {products.map((product) => (
          <div key={product.id} className="productShowCase d-flex flex-wrap justify-content-between">
            {/* Product Gallery */}
            <div className="productGallery">
              <div className="productThumb">
                {product.images?.map((img, index) => (
                  <img
                    key={index}
                    src={img || "/placeholder.png"}
                    onClick={() => setCurrentImg(index)}
                    alt={product.name}
                    height={60}
                  />
                ))}
              </div>
              <div className="productFullImg">
                <img src={product.images?.[currentImg] || "/placeholder.png"} alt={product.name} height={400} />
                <div className="buttonsGroup">
                  <button onClick={() => setCurrentImg(currentImg === 0 ? product.images.length - 1 : currentImg - 1)} className="directionBtn">
                    <GoChevronLeft size={18} />
                  </button>
                  <button onClick={() => setCurrentImg(currentImg === product.images.length - 1 ? 0 : currentImg + 1)} className="directionBtn">
                    <GoChevronRight size={18} />
                  </button>
                </div>
              </div>
            </div>

            {/* Product Details */}
            <div className="productDetails">
              <div className="productName">
                <h1>{product.name}</h1>
              </div>
              <div className="productRating">
                <FaStar color="#FEC78A" size={10} />
                <FaStar color="#FEC78A" size={10} />
                <FaStar color="#FEC78A" size={10} />
                <FaStar color="#FEC78A" size={10} />
                <FaStar color="#FEC78A" size={10} />
                <p>{product.reviews} reviews</p>
              </div>
              <div className="productPrice">
                <h3>${product.price.toFixed(2)}</h3>
              </div>
              <div className="productDescription">
                <p>{product.description || "No description available."}</p>
              </div>

              {/* Size & Color Selection */}
              <div className="productSizeColor">
                {/* Size */}
                <div className="productSize">
                  <p>Sizes</p>
                  <div className="sizeBtn">
                    {["XS", "S", "M", "L", "XL"].map((size) => (
                      <button
                        key={size}
                        style={{
                          borderColor: selectSize === size ? "#000" : "#e0e0e0",
                        }}
                        onClick={() => setSelectSize(size)}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color */}
                <div className="productColor">
                  <p>Color</p>
                  <div className="colorBtn">
                    {["#222222", "#C8393D", "#E4E4E4"].map((color, index) => (
                      <button
                        key={index}
                        style={{
                          backgroundColor: color,
                          border: highlightedColor === color ? "0px solid #000" : "0px solid white",
                          padding: "8px",
                          margin: "5px",
                        }}
                        onClick={() => setHighlightedColor(color)}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Quantity Control */}
              <div className="productQuantityControl">
                <button onClick={() => updateQuantity(product.id, -1)}>-</button>
                <span>{quantities[product.id] || 1}</span>
                <button onClick={() => updateQuantity(product.id, 1)}>+</button>
              </div>

              {/* Add to Cart */}
              <div className="productCartBtn">
                <button onClick={() => addProductToCart(product)}>Add to Cart</button>
              </div>

              {/* Wishlist & Share */}
              <div className="productWishShare">
                <button onClick={() => console.log("Add to Wishlist")}>
                  <FiHeart color="red" size={17} />
                  <p>Add to Wishlist</p>
                </button>
                <div className="productShare">
                  <PiShareNetworkLight size={22} />
                  <p>Share</p>
                </div>
              </div>

              {/* Product Tags */}
              <div className="productTags">
                <p><span>SKU:</span> N/A</p>
                <p><span>CATEGORIES:</span> Casual, Jackets, Men</p>
                <p><span>TAGS:</span> biker, black, leather</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <>
      <div className="container">
        {loading ? <Loading /> : <ShowProducts />}
      </div>
    </>
  );
};

export default Productt;
