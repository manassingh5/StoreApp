import React from "react";
import ContactPage from "../Components/Contact/ContactPage";

const Contact = () => {
  return <ContactPage />;
};

export default Contact;
