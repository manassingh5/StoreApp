// import React, { useState } from "react";
// import "./LoginSignUp.css";
// import { Link } from "react-router-dom";

// const LoginSignUp = () => {
//   const [activeTab, setActiveTab] = useState("tabButton1");

//   const handleTab = (tab) => {
//     setActiveTab(tab);
//   };

//   return (
//     <>
//       <div className="loginSignUpSection">
//         <div className="loginSignUpContainer">
//           <div className="loginSignUpTabs">
//             <p
//               onClick={() => handleTab("tabButton1")}
//               className={activeTab === "tabButton1" ? "active" : ""}
//             >
//               Login
//             </p>
//             <p
//               onClick={() => handleTab("tabButton2")}
//               className={activeTab === "tabButton2" ? "active" : ""}
//             >
//               Register
//             </p>
//           </div>
//           <div className="loginSignUpTabsContent">
//             {/* tab1 */}

//             {activeTab === "tabButton1" && (
//               <div className="loginSignUpTabsContentLogin">
//                 <form>
//                   <input type="email" placeholder="Email address *" required />
//                   <input type="password" placeholder="Password *" required />
//                   <div className="loginSignUpForgetPass">
//                     <label>
//                       <input type="checkbox" className="brandRadio" />
//                       <p>Remember me</p>
//                     </label>
//                     <p>
//                       <Link to="/resetPassword">Lost password?</Link>
//                     </p>
//                   </div>
//                   <button>Log In</button>
//                 </form>
//                 <div className="loginSignUpTabsContentLoginText">
//                   <p>
//                     No account yet?{" "}
//                     <span onClick={() => handleTab("tabButton2")}>
//                       Create Account
//                     </span>
//                   </p>
//                 </div>
//               </div>
//             )}

//             {/* Tab2 */}

//             {activeTab === "tabButton2" && (
//               <div className="loginSignUpTabsContentRegister">
//                 <form>
//                   <input type="text" placeholder="Username *" required />
//                   <input type="email" placeholder="Email address *" required />
//                   <input type="password" placeholder="Password *" required />
//                   <p>
//                     Your personal data will be used to support your experience
//                     throughout this website, to manage access to your account,
//                     and for other purposes described in our
//                     <Link
//                       to="/terms"
//                       style={{ textDecoration: "none", color: "#c32929" }}
//                     >
//                       {" "}
//                       privacy policy
//                     </Link>
//                     .
//                   </p>
//                   <button>Register</button>
//                 </form>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default LoginSignUp;

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import "./LoginSignUp.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const LoginSignUp = () => {
  const [activeTab, setActiveTab] = useState("tabButton1");
  const [formData, setFormData] = useState({
    userName: "",
    password: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    gender: "",
    company: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleTab = (tab) => {
    setActiveTab(tab);
    setFormData({
      userName: "",
      password: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      gender: "",
      company: "",
    }); // Reset form fields
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await axios.post(
        "https://messagingapi.azurewebsites.net/api/auth/Login",
        { userName: formData.userName, password: formData.password }
      );
      const { message, userId } = response.data;

      if (response.status === 200) {
        toast.success(message || "Login successful");
        localStorage.setItem("userId", userId); // Save userId to localStorage
        navigate("/product"); // Navigate to the product page
      } else {
        toast.error(message || "Login failed");
      }
    } catch (error) {
      toast.error("Login failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const genderId = formData.gender === "male" ? 1 : formData.gender === "female" ? 2 : 0;

    const registerRequest = {
      userName: formData.userName,
      password: formData.password,
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone,
      genderId: genderId,
      company: formData.company,
    };

    try {
      const response = await axios.post(
        "https://messagingapi.azurewebsites.net/api/auth/Register",
        registerRequest
      );
      toast.success("Registration successful");
      navigate("/login");
    } catch (error) {
      toast.error("Registration failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className="loginSignUpSection">
        <div className="loginSignUpContainer">
          <div className="loginSignUpTabs">
            <p
              onClick={() => handleTab("tabButton1")}
              className={activeTab === "tabButton1" ? "active" : ""}
            >
              Login
            </p>
            <p
              onClick={() => handleTab("tabButton2")}
              className={activeTab === "tabButton2" ? "active" : ""}
            >
              Register
            </p>
          </div>
          <div className="loginSignUpTabsContent">
            {activeTab === "tabButton1" && (
              <div className="loginSignUpTabsContentLogin">
                <form onSubmit={handleLogin}>
                  <input
                    type="text"
                    name="userName"
                    placeholder="Username *"
                    value={formData.userName}
                    onChange={handleInputChange}
                    required
                  />
                  <input
                    type="password"
                    name="password"
                    placeholder="Password *"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                  />
                  <div className="loginSignUpForgetPass">
                    <label>
                      <input type="checkbox" className="brandRadio" />
                      <p>Remember me</p>
                    </label>
                    <p>
                      <Link to="/resetPassword">Lost password?</Link>
                    </p>
                  </div>
                  <button disabled={isSubmitting}>
                    {isSubmitting ? "Logging in..." : "Log In"}
                  </button>
                </form>
                <div className="loginSignUpTabsContentLoginText">
                  <p>
                    No account yet?{" "}
                    <span onClick={() => handleTab("tabButton2")}>
                      Create Account
                    </span>
                  </p>
                </div>
              </div>
            )}

            {activeTab === "tabButton2" && (
              <div className="loginSignUpTabsContentRegister">
                <form onSubmit={handleRegister}>
                  <input
                    type="text"
                    name="userName"
                    placeholder="Username *"
                    value={formData.userName}
                    onChange={handleInputChange}
                    required
                  />
                  <input
                    type="text"
                    name="firstName"
                    placeholder="First Name *"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                  />
                  <input
                    type="text"
                    name="lastName"
                    placeholder="Last Name *"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Email address *"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                  <input
                    type="tel"
                    name="phone"
                    placeholder="Phone Number *"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                  <input
                    type="text"
                    name="company"
                    placeholder="Company *"
                    value={formData.company}
                    onChange={handleInputChange}
                    required
                  />
                  <input
                    type="password"
                    name="password"
                    placeholder="Password *"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                  />
                  <p>
                    Your personal data will be used to support your experience
                    throughout this website, to manage access to your account,
                    and for other purposes described in our{" "}
                    <Link
                      to="/loginSignUp"
                      style={{ textDecoration: "none", color: "#c32929" }}
                    >
                      privacy policy
                    </Link>
                    .
                  </p>
                  <button disabled={isSubmitting}>
                    {isSubmitting ? "Registering..." : "Register"}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
      <ToastContainer />
    </>
  );
};

export default LoginSignUp;
