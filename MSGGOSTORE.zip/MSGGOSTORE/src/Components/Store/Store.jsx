import React, { useState, useEffect } from "react";
import Skeleton from "react-loading-skeleton";
import { Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import { FaStar } from "react-icons/fa";
import 'react-toastify/dist/ReactToastify.css';
import './Store.css';

const Store = () => {
  const [stores, setStores] = useState([]); // List of stores
  const [loading, setLoading] = useState(true); // Loading state for stores
  const userId = localStorage.getItem("userId"); // Fetch userId from localStorage

  // Fetch stores based on userId
  const fetchStores = async () => {
    try {
      const response = await fetch(
        `https://messagingapi.azurewebsites.net/api/Store/GetStore?UserId=${userId}`
      );
      if (response.ok) {
        const data = await response.json();
        setStores(data); // Set the stores fetched by userId
        setLoading(false); // Stop loading for stores
      } else {
        toast.error("Failed to fetch stores");
        console.error("Error fetching stores:", response.statusText);
      }
    } catch (error) {
      toast.error("Failed to fetch stores");
      console.error("Error fetching stores:", error);
    }
  };

  // Fetch stores when the component mounts
  useEffect(() => {
    fetchStores(); // Fetch stores based on userId
  }, []); // Only run once on mount

  // Loading component for stores
  const Loading = () => (
    <div className="loading-container">
      <div className="loading-cards">
        <Skeleton height={400} width={250} />
        <Skeleton height={400} width={250} />
        <Skeleton height={400} width={250} />
      </div>
    </div>
  );

  // Show stores
  const ShowStores = () => (
    <div className="store-cards">
      {stores.length > 0 ? (
        stores.map((store) => (
          <div key={store.storeId} className="store-card">
            <img
              className="store-img"
              src={store.storeImage || "default-image-url"} // Fallback for missing images
              alt={store.storeName}
            />
            <div className="store-card-body">
              <h5 className="store-title">{store.storeName}</h5>
              <div className="productRating">
                {[...Array(5)].map((_, index) => (
                  <FaStar key={index} color="#FEC78A" size={12} />
                ))}
                <p>8k+ reviews</p>
              </div>
              <p className="store-info">
                <strong>Phone:</strong> {store.storePhone || "N/A"}<br />
                <strong>Address:</strong> {store.address1}, {store.address2 || ""}<br />
                <strong>City:</strong> {store.city || "N/A"}<br />
                <strong>State:</strong> {store.state || "N/A"}<br />
                <strong>Country:</strong> {store.country || "N/A"}<br />
                <strong>Zip Code:</strong> {store.zipCode || "N/A"}<br />
                <strong>Owner:</strong> {store.ownerName || "N/A"}<br />
              </p>
            </div>
            <div className="store-card-footer">
              <Link to={`/products/${store.storeId}`} className="btn btn-dark">
                Show Products
              </Link>
            </div>
          </div>
        ))
      ) : (
        <p>No stores available</p>
      )}
    </div>
  );

  return (
    <>
      <div className="container">
        <div className="row">{loading ? <Loading /> : <ShowStores />}</div>
      </div>

      <ToastContainer position="top-right" autoClose={3000} />
    </>
  );
};

export default Store;
